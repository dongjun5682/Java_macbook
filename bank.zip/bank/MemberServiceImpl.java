package bank;

public class MemberServiceImpl implements MemberService{

	@Override
	public MemberBean join(String name,String ssn,String id,String pass) {
		MemberBean member = new MemberBean();
		member.setId(id);
		member.setName(name);
		member.setPass(pass);
		member.setSsn(ssn);
		return member;
		
	}

	@Override
	public void login() {
//		String res ="";
//		MemberBean member = new MemberBean();
//		System.out.println(member.getId());
//		System.out.println(member.getPass());
//		if(id == member.getId() && pass == member.getPass()) {
//			res = member.toString();
//		}else {
//			res ="일치하지 않습니다.";
//		}
//		return res;
		
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delet() {
		// TODO Auto-generated method stub
		
	}


}
